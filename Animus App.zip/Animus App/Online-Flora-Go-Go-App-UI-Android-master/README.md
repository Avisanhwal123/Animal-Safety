# JetComposeLoginUI
New style for app design Online Flora Go Go App UI made in Jetpack Compose.😉😎

(Navigation Components,
Dagger-Hilt,
Material Components)

# Screenshot

![1_4u3R4q-J33kXxd2SEsTksA](https://user-images.githubusercontent.com/25154589/129550292-26bc36b0-d885-4c22-9e75-d13694bb73f9.jpeg)

![8bbc58e69c36cca86069177544334fb5](https://user-images.githubusercontent.com/25154589/129719795-5a71aceb-f73b-4aa7-84c3-72a4249cb609.png)

![dc46052384d275dca4380cafadc8aad1](https://user-images.githubusercontent.com/25154589/129720116-e8447159-692d-4840-8d8c-00b1e0f8f07c.png)




►Design Credit: https://dribbble.com/shots/11431532-Flower-app
