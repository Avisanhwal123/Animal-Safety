package com.arvind.jetcomposeloginui.utils

object Constants {
    const val SPLASH_SCREEN_DURATION = 0L
}